# ECSE211 Project: Team N - TEAM_NAME

```diff
- For student instructions, see the STUDENT_README.md file.

- Use this file (README.md) to describe the contents of your repo
- (delete all this text shown in red and replace it with your own).

- Also update the title above to include your team number and name.
```
