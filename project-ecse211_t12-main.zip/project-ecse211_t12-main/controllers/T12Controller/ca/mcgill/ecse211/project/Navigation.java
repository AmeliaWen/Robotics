package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import static java.lang.Math.*;
import static simlejos.ExecutionController.sleepFor;

import java.util.ArrayList;
import java.util.Arrays;

import ca.mcgill.ecse211.playingfield.Point;
import ca.mcgill.ecse211.project.ObstacleDetection.usSensorManager;
import simlejos.hardware.ev3.LocalEV3;

public class Navigation {
	// The sample rate for average torque calculation
	private static final int TORQUE_SAMPLING_RATE = 500;
	// Threshold for determining when the robot has left contact with
	// the block
	private static final double TORQUE_THRESHOLD = 0.15;
	// threhold for differentiate block and obstacle
	private static final double THREHOLD = 0.15;
	// An approximate 1% settling time, obtained from a research
	// paper on modelling the EV3 motor
	private static final double MOTOR_SETTLING_TIME = 3.0;

	private static int numSamples = 0; // Counts the number of samples used in the torque average
	private static double torqueSum = 0; // Stores the sum of all torques to be averaged

	/** Do not instantiate this class. */
	private Navigation() {
	}

	private static final int SINTERVAL = 85;

	/** The number of samples in the moving median window. */
	private static final int MOVING_MEDIAN_SAMPLE_COUNT = 8;

	/**
	 * The distance at which the US readings are discarded because it is too far.
	 */
	public static final int MIN_INVALID_DIST = 70;
	private static final int THRESHOLD = 255;
	private static final double LOWER_SENSOR_DISTANCE = 10.5;
	private static final double OBSTACLE_DISTANCE = 2;
	// portion of the distance traversed before calculating torque
	public static final double TORQUE_PUSH_SPLIT = 1 / 4;
	public static final double[] LOCALIZE_MOVE = { -0.05, -0.028 };
	private static int[] usMovingMedianData = new int[MOVING_MEDIAN_SAMPLE_COUNT];

	/** Current US Sensor value in cm. */
	private static int usSensorVal = 0;

	// Stores the 3 average torque values, one for each block
	public static double[] averageTorqueValues = new double[3];

	/**
	 * Does a full turn while looking for blocks.
	 * 
	 */
	public static void simpleSweep(int angleToTurn) {
		// Gets current orientation
		leftMotor.setSpeed(SWEEP_SPEED);
		rightMotor.setSpeed(SWEEP_SPEED);
		double originalAngle = odometer.getXyt()[2];
		odometer.printPosition();

		// Used to know when to stop
		int checkAngle;
		double tileDist;

		switch (angleToTurn) {
		case 180:
			checkAngle = 180;
			tileDist = 0.5;
			break;
		case 270:
			checkAngle = 270;
			tileDist = 0.5;
			break;
		default:
			checkAngle = 360;
			tileDist = 1;
			break;
		}

		// Fills array with values (for median filter)
		for (int i = 0; i < MOVING_MEDIAN_SAMPLE_COUNT; i++) {
			readUsDistance();
		}

		boolean halfWay = false;
		System.out.println("yeet");

		// Starts movement
		// turnBy(angleToTurn+5, true); or
		leftMotor.forward();
		rightMotor.backward();

		System.out.println("yettus");

		double angleDifference = odometer.getXyt()[2] - originalAngle;
		if (angleDifference < 0) {
			angleDifference += 360;
		}
		double lastAngleDifference = angleDifference;

		float[] secondUS = new float[8];
		for (int i = 0; i < 10; i++) {
			secondUS[0] = (new usSensorManager(1)).readUsDistance();
		}
		double distanceBetween, firstSensorReading;

		while (angleDifference < checkAngle) {

			angleDifference = odometer.getXyt()[2] - originalAngle;
			if (angleDifference < 0) {
				angleDifference += 360;
			}

			System.out.println("----------------------new readings ----------------------");
			secondUS[0] = (new usSensorManager(1)).readUsDistance();
			System.out.println("Second sensor reading: " + secondUS[0]);
			firstSensorReading = readUsDistance();
			System.out.println("First sensor reading: " + firstSensorReading);
			distanceBetween = (secondUS[0] - firstSensorReading);
			System.out.println("Distance between 2 readings : " + distanceBetween);

			if (detectBlock(tileDist) && distanceBetween > 12) {
				System.out.println("block detected");
				leftMotor.stop();
				rightMotor.stop();
				firstSensorReading = readUsDistance();
				leftMotor.setSpeed(FORWARD_SPEED);
				rightMotor.setSpeed(FORWARD_SPEED);
				moveStraightFor(firstSensorReading / 100, false);
				Grab();
				LocalEV3.getAudio().beep();
				LocalEV3.getAudio().beep();
				LocalEV3.getAudio().beep();
				break;
				// Go to block and move or smthg
			}
			if (lastAngleDifference > angleDifference) { // when the robot has turned a full 360 degree turn.
				break;
			}
			lastAngleDifference = angleDifference;
		}
		leftMotor.stop();
		rightMotor.stop();
		odometer.printPosition();

	}

	/**
	 * Checks for blocks in front.
	 * 
	 */
	public static boolean detectBlock(double tileDist) {
		double distance = 0;
		for (int i = 0; i < MOVING_MEDIAN_SAMPLE_COUNT; i++) {
			distance = readUsDistance();
		}
		System.out.println("Detect block " + distance);
		System.out.println("Upper limit: " + ((TILE_SIZE * tileDist) * 100 - LOWER_SENSOR_DISTANCE * tileDist));
		if (distance < ((TILE_SIZE * tileDist) * 100 - LOWER_SENSOR_DISTANCE * tileDist)) {
			int disH = ObstacleDetection.getUs().readUsDistance();
			if (Math.abs(disH - distance) > THREHOLD) {
				return true;
			}
		}

		return false;

	}

	/**
	 * Checks for blocks in front.
	 * 
	 */
	public static boolean detectBlockOnLine(int lenghtInTiles) {

		double distance = 0;
		for (int i = 0; i < 10; i++) {
			distance = readUsDistance();
		}
		System.out.println(distance);
		if (distance < ((lenghtInTiles * TILE_SIZE) * 100) - 3.5) {

			return true;
		}

		return false;

	}

	/**
	 * Go to the closest grid intersection on the upper-right. The heading is
	 * restored to /*the original one at the end of the process
	 */
	public static void relocaliseAll() {
		Navigation.relocaliseX();
		Navigation.relocaliseY();
	}

	/**
	 * Travel through a straightline to a destination point.
	 * 
	 * @param destination point
	 */
	public static void simpleTravel2(Point destination) {
		simpleTravel2(destination, true);
	}

	/**
	 * Travel through a straightline to a destination point.
	 * 
	 * @param destination point
	 * 
	 * @param avoid       Indicates whether the robot should be avoiding obstacles
	 *                    while travelling
	 */
	public static void simpleTravel2(Point destination, boolean avoid) {
		double x = destination.x;
		double y = destination.y;
		// difference in X coordinate in metres
		double deltaX = TILE_SIZE * x - Odometer.getOdometer().getXyt()[0];
		// difference in Y coordinate in metres
		double deltaY = TILE_SIZE * y - Odometer.getOdometer().getXyt()[1];
		// difference in X coordinate in tiles
		double deltaX1 = x - Math.round(Odometer.getOdometer().getXyt()[0] / TILE_SIZE);
		// difference in Y coordinate in tiles
		double deltaY1 = y - Math.round(Odometer.getOdometer().getXyt()[1] / TILE_SIZE);
		// heading needed to go to destination
		double finalTheta = Math.toDegrees(Math.atan2(deltaX, deltaY));
		turnTo(finalTheta);
		double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
		moveStraightFor(distance, avoid);

		if (avoid) {
			ObstacleDetection.avoidObstacles(new Point(x, y));
		}

		System.out.println("Robot done moving");
	}

	public static void simpleTravel3(Point destination) {
		double x = destination.x;
		double y = destination.y;
		// difference in X coordinate in metres
		double deltaX = TILE_SIZE * x - Odometer.getOdometer().getXyt()[0];
		// difference in Y coordinate in metres
		double deltaY = TILE_SIZE * y - Odometer.getOdometer().getXyt()[1];
		// difference in X coordinate in tiles
		double deltaX1 = x - Math.round(Odometer.getOdometer().getXyt()[0] / TILE_SIZE);
		// difference in Y coordinate in tiles
		double deltaY1 = y - Math.round(Odometer.getOdometer().getXyt()[1] / TILE_SIZE);
		// heading needed to go to destination
		double finalTheta = Math.toDegrees(Math.atan2(deltaX, deltaY));
		System.out.println(finalTheta);
		turnTo(finalTheta);
		double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
		moveStraightFor(distance);
	}

	/**
	 * Push the block from one grid intersection to another. Updates
	 * averageTorqueValues as it moves.
	 * 
	 * @param destination destination point of the block
	 * @Param index: the block number in the current map
	 */
	public static void simplePushBlockTo(Point destination, int index) {
		double x = destination.x;
		double y = destination.y;
		double deltaX = TILE_SIZE * x - Odometer.getOdometer().getXyt()[0];
		double deltaY = TILE_SIZE * y - Odometer.getOdometer().getXyt()[1];
		double deltaX1 = x - Math.round(Odometer.getOdometer().getXyt()[0] / TILE_SIZE);
		double deltaY1 = y - Math.round(Odometer.getOdometer().getXyt()[1] / TILE_SIZE);
		double finalTheta = Math.toDegrees(Math.atan2(deltaX, deltaY));
		turnTo(finalTheta);
		double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
		// to calculate torque, the robot must already have a stable speed
		moveStraightFor(distance * TORQUE_PUSH_SPLIT); // let the robot go for a while
		moveStraightFor(distance * (1 - TORQUE_PUSH_SPLIT), true); // before starting to calculate torque
		calcAverageTorque(averageTorqueValues, index);

		// Correct for position errors due to torque calculation
		deltaX = TILE_SIZE * x - Odometer.getOdometer().getXyt()[0];
		deltaY = TILE_SIZE * y - Odometer.getOdometer().getXyt()[1];
		distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
		moveStraightFor(distance);
	}

	/**
	 * Navigates to a destination while avoiding obstacles along the way. (not used,
	 * in development) no using for now
	 * 
	 * @param destination destination point
	 */
	public static void simpleTravelObstacle(Point destination) {
		double x = destination.x;
		double y = destination.y;
		double initX = Odometer.getOdometer().getXyt()[0];
		double initY = Odometer.getOdometer().getXyt()[1];
		double deltaX = TILE_SIZE * x - initX;
		double deltaY = TILE_SIZE * y - initY;
		double deltaX1 = x - Math.round(Odometer.getOdometer().getXyt()[0] / TILE_SIZE);
		double deltaY1 = y - Math.round(Odometer.getOdometer().getXyt()[1] / TILE_SIZE);
		double finalTheta = Math.toDegrees(Math.atan2(deltaX1, deltaY1));
		turnTo(finalTheta);
		double distanceTraveled = 0;
		double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

		while (distanceTraveled < distance) {
			odometer.setTheta(finalTheta);
			double deltaXf = Odometer.getOdometer().getXyt()[0] - initX;
			double deltaYf = Odometer.getOdometer().getXyt()[1] - initY;
			distanceTraveled = Math.sqrt(deltaXf * deltaXf + deltaYf * deltaYf);
			int detect = readUsDistance();
			while (detect < 5 && detect > 0) {
				turnBy(20, false);
				detect = readUsDistance();
				/*
				 * this code commented out might be used later if (finalTheta <= 180) {
				 * turnTo(90); moveStraightFor(((Math.tan(Math.toRadians(finalTheta))) * 0.6 *
				 * TILE_SIZE) + 0.5 * TILE_SIZE); turnBy(-90); moveStraightFor(0.6 * TILE_SIZE);
				 * turnBy(-90); moveStraightFor(0.5 * TILE_SIZE); turnBy(90 + finalTheta);
				 * clearUSSensor(); } else { turnTo(-90);
				 * moveStraightFor(((Math.tan(Math.toRadians(finalTheta))) * 0.6 * TILE_SIZE) +
				 * 0.5 * TILE_SIZE); turnBy(90); moveStraightFor(0.6 * TILE_SIZE); turnBy(90);
				 * moveStraightFor(0.5 * TILE_SIZE); turnBy(90 + finalTheta); }
				 */

			}
			if (odometer.getXyt()[2] != finalTheta) {
				moveStraightFor(0.2 * TILE_SIZE);
				turnTo(finalTheta);
			}
			leftMotor.setSpeed(FORWARD_SPEED);
			rightMotor.setSpeed(FORWARD_SPEED);
			leftMotor.forward();
			rightMotor.forward();
		}

	}

	/**
	 * This is the sweeping method we use to find a block in 3*3 square and avoids
	 * the ramp initial version: do not perform object detection
	 * 
	 * @param LL  the lower left corner of the search zone
	 * @param UR  the upper right of the search zone
	 * @param RRL location of the left edge of the ramp
	 * @param RRR location of the right edge of the ramp
	 */
	public static void searchAlg(Point LL, Point UR, Point RRL, Point RRR) {
		int round = (int) (UR.x - LL.x);
		for (int i = 0; i < round; i++) {
			moveStraightFor((UR.y - LL.y - 1) * TILE_SIZE);
			turnBy(90, false);
			moveStraightFor(0.4 * TILE_SIZE);
			turnBy(90, false);
			moveStraightFor((UR.y - LL.y - 1) * TILE_SIZE);
			turnBy(-90, false);
			moveStraightFor(0.4 * TILE_SIZE);
			turnBy(-90, false);
			odometer.setTheta(0);
		}
		int round2 = (int) (RRR.x - RRL.x);
		for (int i = 0; i < round2; i++) {
			moveStraightFor((RRR.y - LL.y - 1) * TILE_SIZE);
			turnBy(90, false);
			moveStraightFor(0.4 * TILE_SIZE);
			turnBy(90, false);
			moveStraightFor((RRR.y - LL.y - 1) * TILE_SIZE);
			turnBy(-90, false);
			moveStraightFor(0.4 * TILE_SIZE);
			turnBy(-90, false);
		}
		int round3 = (int) (UR.x - RRR.x);
		for (int i = 0; i < round3; i++) {
			moveStraightFor((UR.y - LL.y - 1) * TILE_SIZE);
			turnBy(90, false);
			moveStraightFor(0.4 * TILE_SIZE);
			turnBy(90, false);
			moveStraightFor((UR.y - LL.y - 1) * TILE_SIZE);
			turnBy(-90, false);
			moveStraightFor(0.4 * TILE_SIZE);
			turnBy(-90, false);
		}

	}

	public static void simpleTravel2PBridge(Point destination) {
		double x = destination.x;
		double y = destination.y;
		// difference in X coordinate in metres
		double x0 = Odometer.getOdometer().getXyt()[0];
		double y0 = Odometer.getOdometer().getXyt()[1];
		double deltaX = TILE_SIZE * x - Odometer.getOdometer().getXyt()[0];
		// difference in Y coordinate in metres
		double deltaY = TILE_SIZE * y - Odometer.getOdometer().getXyt()[1];
		simpleTravel2(new Point(x0 / TILE_SIZE, y));
		simpleTravel2(new Point(x, y));
	}

	/**
	 * navigates from localization to middle point in search zone for red team
	 * 
	 * @param TNR_LL this is the lower left hand corner of the red tunnel footprint
	 * @param TNR_UR this is the upper right hand corner of the red tunnel footprint
	 * @param Red_UR this is the upper right hand corner of the red zone
	 * @param SZR_LL this is the lower left hand corner of the red zone
	 */
	public static void navigateToBridgeR(Point TNR_LL, Point TNR_UR, Point Red_UR, Point SZR_LL) {
		if (TNR_UR.y == Red_UR.y) {
			simpleTravel2PBridge(new Point(TNR_LL.x - 1, TNR_LL.y));
			relocaliseAll();
			simpleTravel2PBridge(new Point(TNR_LL.x - 1, TNR_LL.y + 0.5));
			turnTo(90);
			relocaliseX();
		} else {
			simpleTravel2PBridge(new Point(TNR_LL.x - 1, TNR_UR.y));
			relocaliseAll();
			simpleTravel2PBridge(new Point(TNR_LL.x - 1, TNR_UR.y - 0.5));
			turnTo(90);
			relocaliseX();
		}
		moveStraightFor((TNR_UR.x - TNR_LL.x + 1.5) * TILE_SIZE);
		// relocaliseX();
		/*
		 * if (TNR_UR.y == SZR_LL.y) { turnBy(-90, false); moveStraightFor(0.5 *
		 * TILE_SIZE); relocaliseAll(); } else { turnBy(90, false); moveStraightFor(0.5
		 * * TILE_SIZE); relocaliseAll(); }
		 */

		// simpleTravel2(new Point(SZR_LL.x + 0.5, SZR_LL.y + 0.5));

	}

	/**
	 * this method returns array of points flagging which tile has been searched we
	 * are not using it for now
	 * 
	 * @param SZR_LL
	 * @param SZR_UR
	 * @param RRL
	 * @param RRR
	 * @return
	 */
	public int[][] filterRamp(Point SZR_LL, Point SZR_UR, Point RRL, Point RRR) {
		int[][] a = new int[4][4];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				a[i][j] = 0;
			}
		}
		if ((RRL.x - SZR_LL.x == 1) && (RRR.y - SZR_LL.y == 2)) {
			a[0][1] = 1;
			a[0][3] = 1;
		} else if ((RRL.x - SZR_LL.x == 2) && (RRR.y - SZR_LL.y == 2)) {
			a[2][0] = 1;
			a[2][2] = 1;
		} else if ((RRL.x - SZR_LL.x == 3) && (RRR.y - SZR_LL.y == 2)) {
			a[2][1] = 1;
			a[2][3] = 1;
		} else if ((RRL.x - SZR_LL.x == 1) && (RRR.y - SZR_LL.y == 1)) {
			a[0][3] = 1;
			a[1][1] = 1;
		} else if ((RRL.x - SZR_LL.x == 2) && (RRR.y - SZR_LL.y == 1)) {
			a[2][2] = 1;
			a[3][0] = 1;
		} else if ((RRL.x - SZR_LL.x == 3) && (RRR.y - SZR_LL.y == 1)) {
			a[2][3] = 1;
			a[3][1] = 1;
		}
		return a;
	}

	/**
	 * this method is called by main to find and navigates to certain waypoints for
	 * red team search zone
	 * 
	 * @param SZR_LL
	 * @param RRR
	 * @param RRL
	 */
	public static void searchZoneNag(Point SZR_LL, Point RRR, Point RRL, Point SZR_UR) {
		ArrayList<Point> pts = new ArrayList<Point>();
		if (RRR.x == RRL.x) {
			if (RRR.x != SZR_LL.x) {
				Point Ramp1 = new Point(RRL.x - 1, RRL.y);
				Point Ramp2 = new Point(RRL.x - 2, RRL.y);
				Point Ramp3 = new Point(RRR.x - 1, RRR.y);
				Point Ramp4 = new Point(RRR.x - 2, RRR.y);
				pts.add(Ramp1);
				pts.add(Ramp2);
				pts.add(Ramp3);
				pts.add(Ramp4);
				pts.add(RRL);
				pts.add(RRR);
			} else {
				Point Ramp1 = new Point(RRL.x + 1, RRL.y);
				Point Ramp2 = new Point(RRL.x + 2, RRL.y);
				Point Ramp3 = new Point(RRR.x + 1, RRR.y);
				Point Ramp4 = new Point(RRR.x + 2, RRR.y);
				pts.add(Ramp1);
				pts.add(Ramp2);
				pts.add(Ramp3);
				pts.add(Ramp4);
				pts.add(RRL);
				pts.add(RRR);
			}

		} else if (RRR.y == RRL.y) {
			Point Ramp1 = new Point(RRL.x, RRL.y + 1);
			Point Ramp2 = new Point(RRL.x, RRL.y + 2);
			Point Ramp3 = new Point(RRR.x, RRR.y + 1);
			Point Ramp4 = new Point(RRR.x, RRR.y + 2);
			pts.add(Ramp1);
			pts.add(Ramp2);
			pts.add(Ramp3);
			pts.add(Ramp4);
			pts.add(RRL);
			pts.add(RRR);
		}
		ArrayList<Point> destinations = new ArrayList<Point>();
		int width = (int) (SZR_UR.x - SZR_LL.x);
		int height = (int) (SZR_UR.y - SZR_LL.y);
		if (width == 4 && height == 4) {
			Point des1 = new Point(SZR_LL.x + 1, SZR_LL.y + 3);
			Point des2 = new Point(SZR_LL.x + 1, SZR_LL.y + 1);
			Point des3 = new Point(SZR_LL.x + 3, SZR_LL.y + 1);
			Point des4 = new Point(SZR_LL.x + 3, SZR_LL.y + 3);
			destinations.add(des1);
			destinations.add(des2);
			destinations.add(des3);
			destinations.add(des4);
		} else {
			if (width > 0 && (height>0)) {
				for (int i = 0; i < width / 2; i++) {
					if (Math.floorMod(i, 2)== 0 ) {
						for (int j = height / 2 -1 ; j >=0 ; j--) {
							Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_LL.y + 1 + 2*j);
							//System.out.println(des.x + " " +des.y);
							destinations.add(des);
						}
					}else {
						for (int j = 0; j < height / 2; j++) {
							Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_LL.y + 1 + 2*j);
							//System.out.println(des.x + " " +des.y);
							destinations.add(des);
						}
					}
					
				}
			}else {
				if (height <0 && (width>0)) {
					height = -height;
					for (int i = 0; i < width / 2; i++) {
						if (Math.floorMod(i, 2)== 0 ) {
							for (int j = height / 2 -1 ; j >=0 ; j--) {
								Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_UR.y + 1 + 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}else {
							for (int j = 0; j < height / 2; j++) {
								Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_UR.y + 1 + 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}
						
					}
				}
				if (width<0 &&(height>0)) {
					width= -width;
					for (int i = 0; i < width / 2; i++) {
						if (Math.floorMod(i, 2)== 0 ) {
							for (int j = 0  ; j < height / 2 ; j++) {
								Point des = new Point(SZR_LL.x - 1 - 2*i, SZR_UR.y - 1 - 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}else {
							for (int j = height / 2 -1; j >= 0 ; j--) {
								Point des = new Point(SZR_LL.x - 1 - 2*i, SZR_UR.y - 1 - 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}
						
					}
				}
				if (width<0 &&(height <0)) {
					width= -width;
					height = -height;
					for (int i = 0; i < height / 2; i++) {
						if (Math.floorMod(i, 2)== 0 ) {
							for (int j = 0  ; j < width / 2 ; j++) {
								Point des = new Point(SZR_LL.x - 1 - 2*j, SZR_LL.y - 1 - 2*i);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}else {
							for (int j = width / 2 -1; j >= 0 ; j--) {
								Point des = new Point(SZR_LL.x - 1 - 2*j, SZR_LL.y - 1 - 2*i);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}
						
					}
				}
			}
		}

		

		for (int i = 0; i < destinations.size(); i++) {
			Point p = destinations.get(i);
			System.out.println(p.x + " " + p.y);
			// simpleTravel2P(p);
			rotatePattern(pts, p, RRR, RRL, i);
		}
	}
	public static ArrayList<Point> testPoints (Point SZR_LL, Point SZR_UR){
		ArrayList<Point> destinations = new ArrayList<Point>();
		int width = (int) (SZR_UR.x - SZR_LL.x);
		int height = (int) (SZR_UR.y - SZR_LL.y);
		if (width == 4 && height == 4) {
			Point des1 = new Point(SZR_LL.x + 1, SZR_LL.y + 3);
			Point des2 = new Point(SZR_LL.x + 1, SZR_LL.y + 1);
			Point des3 = new Point(SZR_LL.x + 3, SZR_LL.y + 1);
			Point des4 = new Point(SZR_LL.x + 3, SZR_LL.y + 3);
			destinations.add(des1);
			destinations.add(des2);
			destinations.add(des3);
			destinations.add(des4);
		} else {
			if (width > 0 && (height>0)) {
				for (int i = 0; i < width / 2; i++) {
					if (Math.floorMod(i, 2)== 0 ) {
						for (int j = height / 2 -1 ; j >=0 ; j--) {
							Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_LL.y + 1 + 2*j);
							//System.out.println(des.x + " " +des.y);
							destinations.add(des);
						}
					}else {
						for (int j = 0; j < height / 2; j++) {
							Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_LL.y + 1 + 2*j);
							//System.out.println(des.x + " " +des.y);
							destinations.add(des);
						}
					}
					
				}
			}else {
				if (height <0 && (width>0)) {
					height = -height;
					for (int i = 0; i < width / 2; i++) {
						if (Math.floorMod(i, 2)== 0 ) {
							for (int j = height / 2 -1 ; j >=0 ; j--) {
								Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_UR.y + 1 + 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}else {
							for (int j = 0; j < height / 2; j++) {
								Point des = new Point(SZR_LL.x + 1 + 2*i, SZR_UR.y + 1 + 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}
						
					}
				}
				if (width<0 &&(height>0)) {
					width= -width;
					for (int i = 0; i < width / 2; i++) {
						if (Math.floorMod(i, 2)== 0 ) {
							for (int j = 0  ; j < height / 2 ; j++) {
								Point des = new Point(SZR_LL.x - 1 - 2*i, SZR_UR.y - 1 - 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}else {
							for (int j = height / 2 -1; j >= 0 ; j--) {
								Point des = new Point(SZR_LL.x - 1 - 2*i, SZR_UR.y - 1 - 2*j);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}
						
					}
				}
				if (width<0 &&(height <0)) {
					width= -width;
					height = -height;
					for (int i = 0; i < height / 2; i++) {
						if (Math.floorMod(i, 2)== 0 ) {
							for (int j = 0  ; j < width / 2 ; j++) {
								Point des = new Point(SZR_LL.x - 1 - 2*j, SZR_LL.y - 1 - 2*i);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}else {
							for (int j = width / 2 -1; j >= 0 ; j--) {
								Point des = new Point(SZR_LL.x - 1 - 2*j, SZR_LL.y - 1 - 2*i);
								//System.out.println(des.x + " " +des.y);
								destinations.add(des);
							}
						}
						
					}
				}
			}
			

		}
		for (int i = 0;i<destinations.size();i++) {
			System.out.println(destinations.get(i));
		}
		
		return destinations;
	}

	/**
	 * this method change if a point (odometer/specific waypoint is inside the ramp)
	 * 
	 * @param p
	 * @param RRR
	 * @param RRL
	 * @return
	 */
	public static boolean pointInRange(Point p, Point RRR, Point RRL) {
		if (RRR.y == RRL.y) {
			if (((RRL.x - 0.3 <= p.x) && (p.x <= RRR.x + 0.3)) && ((RRR.y - 0.3 <= p.y) && (p.y <= RRL.y + 2.3))) {
				return true;
			}
		} else if (RRR.x == RRL.x) {
			// horizontal ramp
			if (((RRR.x - 0.3 <= p.x) && (p.x <= RRR.x + 2.3)) && ((RRR.y - 0.3 <= p.y) && (p.y <= RRL.y + 0.3))) {
				return true;
			}
		}
		return false;
	}

	public static boolean pointInRangeS(Point p, Point RRR, Point RRL) {
		if (RRR.y == RRL.y) {
			if (((RRL.x - 0.1 <= p.x) && (p.x <= RRR.x + 0.1)) && ((RRR.y - 0.1 <= p.y) && (p.y <= RRL.y + 2.1))) {
				return true;
			}
		} else if (RRR.x == RRL.x) {
			// horizontal ramp
			if (((RRR.x - 0.1 <= p.x) && (p.x <= RRR.x + 2.1)) && ((RRR.y - 0.1 <= p.y) && (p.y <= RRL.y + 0.1))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * this method uses simpleTravel2 to travel perpendicularly to des
	 * 
	 * @param des
	 * @param RRR
	 * @param RRL
	 * @param i   indicates the zone number we are traveling to
	 */
	public static void simpleTravel2P(Point des, Point RRR, Point RRL, int i) {
		double x = des.x;
		double y = des.y;
		double x0 = Odometer.getOdometer().getXyt()[0];
		double y0 = Odometer.getOdometer().getXyt()[1];
		System.out.println(x0 / TILE_SIZE + "cur" + y0 / TILE_SIZE);
		if (pointInRange(new Point(x0 / TILE_SIZE, y), RRR, RRL)) {
			System.out.println(x + " " + y0 / TILE_SIZE);
			simpleTravel2(new Point(x, y0 / TILE_SIZE));
			simpleTravel2(new Point(x, y));
		} else {
			if ((pointInRange(new Point((x + x0 / TILE_SIZE) / 2, (y + y0 / TILE_SIZE) / 2), RRR, RRL)
					&& (((x0 / TILE_SIZE > x) && (y < y0 / TILE_SIZE))
							|| ((x0 / TILE_SIZE < x) && (y > y0 / TILE_SIZE))))
					|| (pointInRangeS(new Point((x + x0 / TILE_SIZE) / 2, (y + y0 / TILE_SIZE) / 2), RRR, RRL))) {
				System.out.println("points in range" + i);
				if (i == 1) {
					if (pointInRangeS(new Point((x + x0 / TILE_SIZE) / 2, (y + y0 / TILE_SIZE) / 2), RRR, RRL)) {
						turnTo(90);
						simpleTravel2(new Point(x0 / TILE_SIZE + 1.1, y0 / TILE_SIZE));
						simpleTravel2(new Point(x0 / TILE_SIZE + 1.1, y));
						simpleTravel2(new Point(x, y));
					} else {
						turnTo(-90);
						simpleTravel2(new Point(x0 / TILE_SIZE - 0.3, y0 / TILE_SIZE));
						simpleTravel2(new Point(x0 / TILE_SIZE - 0.3, y));
						simpleTravel2(new Point(x, y));
					}

				} else if (i == 2) {
					if (pointInRangeS(new Point((x + x0 / TILE_SIZE) / 2, (y + y0 / TILE_SIZE) / 2), RRR, RRL)) {
						turnTo(0);
						simpleTravel2(new Point(x0 / TILE_SIZE, y0 / TILE_SIZE + 1.1));
						simpleTravel2(new Point(x, y0 / TILE_SIZE + 1.1));
						simpleTravel2(new Point(x, y));
					} else {
						turnTo(90);
						simpleTravel2(new Point(x, y0 / TILE_SIZE));
						// simpleTravel2(new Point (x, y0/TILE_SIZE+1.1));
						simpleTravel2(new Point(x, y));
					}
				} else if (i == 3) {
					if (pointInRangeS(new Point((x + x0 / TILE_SIZE) / 2, (y + y0 / TILE_SIZE) / 2), RRR, RRL)) {
						turnTo(-90);
						simpleTravel2(new Point(x0 / TILE_SIZE - 1.1, y0 / TILE_SIZE));
						simpleTravel2(new Point(x0 / TILE_SIZE - 1.1, y));
						simpleTravel2(new Point(x, y));
					} else {
						turnTo(90);
						simpleTravel2(new Point(x0 / TILE_SIZE + 0.3, y0 / TILE_SIZE));
						simpleTravel2(new Point(x0 / TILE_SIZE + 0.3, y));
						simpleTravel2(new Point(x, y));
					}

				}

			} else {
				System.out.println(x0 / TILE_SIZE + "simple situation" + y);
				simpleTravel2(new Point(x0 / TILE_SIZE, y));
				simpleTravel2(new Point(x, y));
			}
		}

		// difference in X coordinate in metres
		/*
		 * double deltaX = Math.abs(TILE_SIZE * x - Odometer.getOdometer().getXyt()[0]);
		 * // difference in Y coordinate in metres double deltaY = Math.abs(TILE_SIZE *
		 * y - Odometer.getOdometer().getXyt()[1]); moveStraightFor(deltaY); turnBy(90);
		 * moveStraightFor(deltaX);
		 */

	}

	/**
	 * this method takes in array of ramp coordinates and check if a point matches
	 * one of the ramp coordinates.
	 * 
	 * @param points
	 * @param destination
	 * @return
	 */
	public static boolean filterRampv2(ArrayList<Point> points, Point destination) {
		for (Point point : points) {
			if (point.x == destination.x && (point.y == destination.y)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * this is the main method we call in the search algorithm method, it is called
	 * on each zone, navigates to specific waypoints without hitting the ramp, and
	 * turn to specific angle in order to perform sweeping
	 * 
	 * @param points      the points of ramp
	 * @param destination the desired point to travel initially (middle of each
	 *                    search zone)
	 * @param RRR
	 * @param RRL
	 * @param i           the zone index traveling to
	 */
	public static void rotatePattern(ArrayList<Point> points, Point destination, Point RRR, Point RRL, int i) {
		if (!filterRampv2(points, destination)) {
			simpleTravel2P(destination, RRR, RRL, i);
			relocaliseAll();

			simpleSweep(360);
			relocaliseAll();
		} else {
			boolean lh = filterRampv2(points, new Point(destination.x - 1, destination.y));
			boolean lt = filterRampv2(points, new Point(destination.x - 1, destination.y + 1));
			boolean t = filterRampv2(points, new Point(destination.x, destination.y + 1));
			boolean rt = filterRampv2(points, new Point(destination.x + 1, destination.y + 1));
			boolean rh = filterRampv2(points, new Point(destination.x + 1, destination.y));
			boolean d = filterRampv2(points, new Point(destination.x, destination.y - 1));
			boolean ld = filterRampv2(points, new Point(destination.x - 1, destination.y - 1));
			boolean rd = filterRampv2(points, new Point(destination.x + 1, destination.y - 1));
			// rotate clockwise 180 degree
			if ((lt == true) && (rt == true) && (rh == true) && (lh == true)) {
				System.out.println("case1");
				simpleTravel2P(new Point(destination.x, destination.y - 0.5), RRR, RRL, i);
				turnTo(90);
				simpleSweep(180);
			} else if ((lh == true) && (rh == true) && (ld == true) && (rd == true)) {
				System.out.println("case2");
				simpleTravel2P(new Point(destination.x, destination.y + 0.5), RRR, RRL, i);
				turnTo(-90);
				simpleSweep(180);
			} else if ((lt == true) && (ld == true) && (t == true) && (d == true)) {
				System.out.println("case3");
				simpleTravel2P(new Point(destination.x + 0.5, destination.y), RRR, RRL, i);
				turnTo(0);
				simpleSweep(180);
			} else if ((t == true) && (d == true) && (rt == true) && (rd == true)) {
				System.out.println("case4");
				simpleTravel2P(new Point(destination.x - 0.5, destination.y), RRR, RRL, i);
				turnTo(180);
				simpleSweep(180);
			}
			// rotate clockwise 270 degree
			else if ((lt == true) && (t == true) && (lh == true)) {
				System.out.println("case5");
				simpleTravel2P(new Point(destination.x + 0.4, destination.y - 0.4), RRR, RRL, i);
				turnTo(0);
				simpleSweep(270);
				simpleTravel2P(new Point(destination.x + 0.4, destination.y), RRR, RRL, i);
				relocaliseY();
			} else if ((t == true) && (rt == true) && (rh == true)) {
				System.out.println("case6");
				if (i == 2) {
					simpleTravel2P(new Point(destination.x - 0.4, destination.y - 0.4), RRR, RRL, i);
					turnTo(90);
					simpleSweep(270);
					simpleTravel2P(new Point(destination.x - 0.4, destination.y), RRR, RRL, i);
					relocaliseY();
				}
				if (i == 1) {
					simpleTravel2P(new Point(destination.x - 0.4, destination.y - 0.4), RRR, RRL, i);
					turnTo(90);
					simpleSweep(270);
					// simpleTravel2P(new Point (destination.x-0.4, destination.y), RRR, RRL, i);
					// relocaliseY();
				}

			} else if ((lh == true) && (ld == true) && (d == true)) {
				System.out.println("case7");
				simpleTravel2P(new Point(destination.x + 0.4, destination.y), RRR, RRL, i);
				relocaliseY();
				simpleTravel2P(new Point(destination.x + 0.4, destination.y + 0.4), RRR, RRL, i);
				turnTo(-90);
				simpleSweep(270);
			} else if ((rh == true) && (rd == true) && (d == true)) {
				System.out.println("case8");
				simpleTravel2P(new Point(destination.x - 0.4, destination.y), RRR, RRL, i);
				relocaliseY();
				simpleTravel2P(new Point(destination.x - 0.4, destination.y + 0.4), RRR, RRL, i);
				turnTo(180);
				simpleSweep(270);
			}
		}

	}

	/**
	 * navigates from localization to middle point in search zone for green team
	 * 
	 * @param TNG_LL   this is the lower left hand corner of the green tunnel
	 *                 footprint
	 * @param TNG_UR   this is the upper right hand corner of the green tunnel
	 *                 footprint
	 * @param Green_UR this is the upper right hand corner of the green zone
	 * @param SZG_LL   this is the lower left hand corner of the green zone
	 */
	public static void navigateToBridgeG(Point TNG_LL, Point TNG_UR, Point Green_UR, Point SZG_LL) {
		if (TNG_UR.x == Green_UR.x) {
			simpleTravel2(new Point(TNG_LL.x, TNG_LL.y - 1));
			relocaliseAll();
			simpleTravel2(new Point(TNG_LL.x + 0.5, TNG_LL.y - 1));
			turnTo(0);
			relocaliseY();
		} else {
			simpleTravel2(new Point(TNG_UR.x, TNG_LL.y - 1));
			relocaliseAll();
			simpleTravel2(new Point(TNG_UR.x - 0.5, TNG_LL.y - 1));
			turnTo(0);
			relocaliseY();
		}
		moveStraightFor((TNG_UR.y - TNG_LL.y + 2) * TILE_SIZE);
		relocaliseY();
		if (SZG_LL.x == TNG_UR.x) {
			turnBy(90, false);
		} else {
			turnBy(-90, false);
		}

		moveStraightFor(0.5 * TILE_SIZE);
		relocaliseAll();
		// simpleTravel2(new Point(SZG_LL.x + 0.5, SZG_LL.y + 0.5));
	}

	/**
	 * Relocalizes the bot to the next horizontal gridline. Adjust odometry as
	 * needed.
	 */
	public static void relocaliseY() {

		double curAngle = odometer.getXyt()[2];
		turnTo(0);
		moveStraightFor(LOCALIZE_MOVE[0]); // moves back a bit
		LightLocalizer.goToNextLine();
		odometer.setTheta(0);
		moveStraightFor(LOCALIZE_MOVE[1]); // moves back more to prepare for rotation

		turnTo(curAngle);

		// odometry must show integer coordinate if robot is localized
		odometer.setY(TILE_SIZE * (Math.round(odometer.getXyt()[1] / TILE_SIZE)));

		System.out.println("X : " + odometer.getXyt()[0] / TILE_SIZE + "   Y : " + odometer.getXyt()[1] / TILE_SIZE);

	}

	/**
	 * Relocalizes the bot to the next vertical gridline to the right. Adjust
	 * odometry as needed.
	 */
	public static void relocaliseX() {
		double curAngle = odometer.getXyt()[2];
		turnTo(90);
		moveStraightFor(LOCALIZE_MOVE[0]);
		LightLocalizer.goToNextLine();
		odometer.setTheta(90);
		moveStraightFor(LOCALIZE_MOVE[1]);
		turnTo(curAngle);
		odometer.setX(TILE_SIZE * (Math.round(odometer.getXyt()[0] / TILE_SIZE)));
		System.out.println("X : " + odometer.getXyt()[0] / TILE_SIZE + "   Y : " + odometer.getXyt()[1] / TILE_SIZE);
	}

	/**
	 * Turns the robot with a minimal angle towards the given input angle in
	 * degrees, no matter what its current orientation is. This method is different
	 * from {@code turnBy()}.
	 * 
	 * @param angle in degrees. Where 0 is straight ahead. 90 degrees is to the
	 *              right.
	 */
	public static void turnTo(double angle) {

		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		double turningAngle = minimalAngle(Odometer.getOdometer().getXyt()[2], angle);
		leftMotor.rotate(convertAngle(turningAngle), true);
		rightMotor.rotate(-convertAngle(turningAngle), false);

	}

	/**
	 * Returns the angle that the robot should point towards to face the destination
	 * in degrees.
	 */
	public static double getDestinationAngle(Point current, Point destination) {
		double dx = destination.x - current.x;
		double dy = destination.y - current.y;
		double dt = Math.toDegrees(Math.atan2(dy, dx));
		if (dx < 0 && dy > 0) {
			return 360 - (dt - 90);
		}
		if (dx < 0 && dy < 0) {
			return -dt + 90;
		}
		if (dx > 0 && dy < 0) {
			return -dt + 90;
		}
		if (dx > 0 && dy > 0) {
			return 90 - dt;
		}
		if (dx == 0 && dy < 0) {
			return 180;
		}
		if (dx == 0 && dy > 0) {
			return 0;
		}
		if (dy == 0 && dx < 0) {
			return 270;
		}
		if (dy == 0 && dx > 0) {
			return 90;
		}
		return dt;
	}

	/**
	 * Returns the signed minimal angle in degrees from initial angle to destination
	 * angle (deg).
	 */
	public static double minimalAngle(double initialAngle, double destAngle) {
		double turningAngle = destAngle - initialAngle;
		if (turningAngle > 180) {
			turningAngle -= 360;
		}
		// angle < 180, increase by 360
		if (turningAngle < -180) {
			turningAngle += 360;
		}
		return turningAngle;
	}

	/** Returns the distance between the two points in tile lengths (feet). */
	public static double distanceBetween(Point p1, Point p2) {
		return Math.sqrt((p2.x - p1.x) * (p2.x - p1.x) + (p2.y - p1.y) * (p2.y - p1.y));
	}

	// You can also add other helper methods here, but remember to document them
	// with Javadoc (/**)!
	/**
	 * Converts input distance to the total rotation of each wheel needed to cover
	 * that distance.
	 * 
	 * @param distance the input distance in meters
	 * @return the wheel rotations necessary to cover the distance
	 */
	public static int convertDistance(double distance) {
		return (int) ((distance * 180.0) / (Math.PI * WHEEL_RAD));
	}

	/**
	 * Converts input angle to the total rotation of each wheel needed to rotate the
	 * robot by that angle.
	 * 
	 * @param angle the input angle in degrees
	 * @return the wheel rotations necessary to rotate the robot by the angle
	 */
	public static int convertAngle(double angle) {
		return convertDistance((angle * Math.PI * BASE_WIDTH) / 360.0);
	}

	/**
	 * Turns the robot by a specified angle. Note that this method is different from
	 * {@code Navigation.turnTo()}. For example, if the robot is facing 90 degrees,
	 * calling {@code turnBy(90)} will make the robot turn to 180 degrees, but
	 * calling {@code Navigation.turnTo(90)} should do nothing (since the robot is
	 * already at 90 degrees).
	 * 
	 * @param angle the angle by which to turn, in degrees
	 */

	public static void turnBy(double angle, boolean immediateReturn) {

		if (angle > 180) {
			angle -= 360;
		}
		// angle < 180, increase by 360
		if (angle < -180) {
			angle += 360;
		}
		int wheelAngle = convertAngle(angle);
		leftMotor.rotate(wheelAngle, true);
		rightMotor.rotate(-wheelAngle, immediateReturn);
	}

	/**
	 * Turns the robot to the desired angle.
	 * 
	 * @param angle The angle to which the robot should turn
	 */
	public static void turnToOld(int angle) {
		angle = Math.abs(angle);
		angle = angle % 360;

		int currentAngle = (int) odometer.getXyt()[2];
		turnBy(angle - currentAngle, false);

	}

	/**
	 * Moves the robot straight for the given distance.
	 * 
	 * @param distance in meters, may be negative
	 */
	public static void moveStraightFor(double distance) {
		moveStraightFor(distance, false);
	}

	/**
	 * Moves the robot straight for the given distance, returns immediately if true
	 * is passed.
	 * 
	 * @param distance  in meters, may be negative
	 * @param returnVal whether or not the method should return immediately
	 */
	public static void moveStraightFor(double distance, boolean returnVal) {
		int angle = convertDistance(distance);
		leftMotor.rotate(angle, true);
		rightMotor.rotate(angle, returnVal);
	}

	/**
	 * Stops both motors.
	 */
	public static void stopMotors() {
		leftMotor.stop();
		rightMotor.stop();
	}

	/**
	 * Starts both motors. (this method only calls forward() on them, it does not
	 * set speed or acceleration).
	 */
	public static void startMotors() {
		leftMotor.forward();
		rightMotor.forward();
	}

	/**
	 * Sets the speed of both motors.
	 * 
	 * @param speed The speed at which to set both motors
	 */
	public static void setBothSpeed(int speed) {
		leftMotor.setSpeed(speed);
		rightMotor.setSpeed(speed);
	}

	/**
	 * This method stops both motors and sets their speed to 0 degree/s.
	 */
	public static void stopMotorsRemoveSpeed() {
		leftMotor.setSpeed(0);
		rightMotor.setSpeed(0);
		Navigation.stopMotors();
	}

	/**
	 * This method will set the acceleration and speed of the motors to default
	 * values.
	 */
	public static void prepareMotorsRotate() {
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
	}

	/**
	 * Initializes a thread to calculate average torque, returns average torque to a
	 * given array index. Assumes the method is only called when a change in torque
	 * is expected
	 */
	public static void calcAverageTorque(double[] arr, int index) {
		/* Reset variables */
		numSamples = 0;
		torqueSum = 0;

		double curTorque, prevTorque; // Stores current and previous torque, used in break case for while loop
		double timePassed = 0; // Used to ignore any torque values from within the MOTOR_SETTLING_TIME

		/* Initialize curTorque & prevTorque */
		curTorque = (rightMotor.getTorque() + leftMotor.getTorque()) / 2;
		prevTorque = curTorque;
		torqueSum += curTorque;
		numSamples++;

		/* Sums torque values while torque is within a threshold value */
		while (Math.abs(Math.abs(curTorque) - Math.abs(prevTorque)) < TORQUE_THRESHOLD
				|| timePassed <= MOTOR_SETTLING_TIME) {
			sleepFor(TORQUE_SAMPLING_RATE); // Polls torque at 2 Hz
			timePassed += 0.5; // Increments the passed time

			/* Update torque values */
			prevTorque = curTorque;
			curTorque = (rightMotor.getTorque() + leftMotor.getTorque()) / 2;

			if (timePassed >= MOTOR_SETTLING_TIME) { // Ignore values if they are within the
				// motor settling time
				torqueSum += curTorque;
				numSamples++;
			}

			System.out.println(leftMotor.getTorque() + " " + rightMotor.getTorque() + " " + curTorque);
		}

		System.out.println(torqueSum / numSamples);
		arr[index] = torqueSum / numSamples; // Print the average result to an array
	}

	private static int readUsDistance() {
		sleepFor(SINTERVAL);
		/* Shift array values over to make space for new sample */
		for (int i = MOVING_MEDIAN_SAMPLE_COUNT - 1; i > 0; i--) {
			usMovingMedianData[i] = usMovingMedianData[i - 1];
		}
		// Get the current sample, ensure it is within the range of accepted values
		usMovingMedianData[0] = Math.min(THRESHOLD, (int) fetchSample());

		usSensorVal = medianFilter(usMovingMedianData);
		return usSensorVal;
	}

	/**
	 * Fetchs an unfiltered sample from the sensor.
	 */
	private static float fetchSample() {
		float[] distValue = new float[usSensor.sampleSize()];
		usSensor.fetchSample(distValue, 0);
		return distValue[0] * 100;
	}

	/**
	 * Performs a median filter on a data set. Uses bubble sort
	 */
	public static int medianFilter(int[] data) {
		int median;
		int[] sortedData = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			sortedData[i] = data[i]; // Copy values into new array
		}
		Arrays.sort(sortedData);
		if ((data.length) % 2 == 0) {
			median = (sortedData[data.length / 2] + sortedData[1 + data.length / 2]) / 2;
		} else {
			median = sortedData[data.length / 2];
		}
		return median;
	}

	/**
	 * Performs a median filter on a data set. Uses bubble sort
	 */
	public static double medianFilter(double[] data) {
		double median;
		double[] sortedData = new double[data.length];
		for (int i = 0; i < data.length; i++) {
			sortedData[i] = data[i]; // Copy values into new array
		}
		Arrays.sort(sortedData);
		if ((data.length) % 2 == 0) {
			median = (sortedData[data.length / 2] + sortedData[1 + data.length / 2]) / 2;
		} else {
			median = sortedData[data.length / 2];
		}
		return median;
	}

	/**
	 * .
	 * 
	 */
	public static void clearUSSensor() {
		for (int i = 0; i < MOVING_MEDIAN_SAMPLE_COUNT; i++) {
			usMovingMedianData[i] = 255;
		}
	}

	/** Travels to the given destination. */
	public static void travelTo(Point destination) {
		var xyt = odometer.getXyt();
		var currentLocation = new Point(xyt[0] / TILE_SIZE, xyt[1] / TILE_SIZE);
		var currentTheta = xyt[2];
		var destinationTheta = getDestinationAngle(currentLocation, destination);
		turnBy(minimalAngle(currentTheta, destinationTheta), false);
		moveStraightFor(distanceBetween(currentLocation, destination));
	}

	/**
	 * Returns the angle that the robot should point towards to face the destination
	 * in degrees.
	 */
	/*
	 * public static double getDestinationAngle(Point current, Point destination) {
	 * return (toDegrees(atan2(destination.x - current.x, destination.y -
	 * current.y)) + 360) % 360; }
	 */

	/**
	 * Returns the signed minimal angle from the initial angle to the destination
	 * angle.
	 */
	/*
	 * public static double minimalAngle(double initialAngle, double destAngle) {
	 * var dtheta = destAngle - initialAngle; if (dtheta < -180) { dtheta += 360; }
	 * else if (dtheta > 180) { dtheta -= 360; } return dtheta; }
	 */

	/** Returns the distance between the two points in tile lengths. */
	/*
	 * public static double distanceBetween(Point p1, Point p2) { var dx = p2.x -
	 * p1.x; var dy = p2.y - p1.y; return sqrt(dx * dx + dy * dy); }
	 */

	// TODO Bring Navigation-related helper methods from Labs 2 and 3 here

	/**
	 * Moves the robot straight for the given distance.
	 * 
	 * @param distance in feet (tile sizes), may be negative
	 */
	/*
	 * public static void moveStraightFor(double distance) {
	 * setSpeed(FORWARD_SPEED); leftMotor.rotate(convertDistance(distance *
	 * TILE_SIZE), true); rightMotor.rotate(convertDistance(distance * TILE_SIZE),
	 * false); }
	 */

	/** Moves the robot forward for an indeterminate distance. */
	public static void forward() {
		setSpeed(FORWARD_SPEED);
		leftMotor.forward();
		rightMotor.forward();
	}

	/** Moves the robot backward for an indeterminate distance. */
	public static void backward() {
		setSpeed(FORWARD_SPEED);
		leftMotor.backward();
		rightMotor.backward();
	}

	/**
	 * Turns the robot by a specified angle. Note that this method is different from
	 * {@code turnTo()}. For example, if the robot is facing 90 degrees, calling
	 * {@code turnBy(90)} will make the robot turn to 180 degrees, but calling
	 * {@code turnTo(90)} should do nothing (since the robot is already at 90
	 * degrees).
	 * 
	 * @param angle the angle by which to turn, in degrees
	 */
	/*
	 * public static void turnBy(double angle) { setSpeed(ROTATE_SPEED);
	 * leftMotor.rotate(convertAngle(angle), true);
	 * rightMotor.rotate(-convertAngle(angle), false); }
	 */

	/** Rotates motors clockwise. */
	public static void clockwise() {
		setSpeed(ROTATE_SPEED);
		leftMotor.forward();
		rightMotor.backward();
	}

	/** Rotates motors counterclockwise. */
	public static void counterclockwise() {
		setSpeed(ROTATE_SPEED);
		leftMotor.backward();
		rightMotor.forward();
	}

	/** Stops both motors. This also resets the motor speeds to zero. */
	/*
	 * public static void stopMotors() { leftMotor.stop(); rightMotor.stop(); }
	 */

	/**
	 * Converts input distance to the total rotation of each wheel needed to cover
	 * that distance.
	 * 
	 * @param distance the input distance in meters
	 * @return the wheel rotations necessary to cover the distance in degrees
	 */
	/*
	 * public static int convertDistance(double distance) { return (int)
	 * toDegrees(distance / WHEEL_RAD); }
	 */

	/**
	 * Converts input angle to total rotation of each wheel needed to rotate robot
	 * by that angle.
	 * 
	 * @param angle the input angle in degrees
	 * @return the wheel rotations (in degrees) necessary to rotate the robot by the
	 *         angle
	 */
	/*
	 * public static int convertAngle(double angle) { return
	 * convertDistance(toRadians((BASE_WIDTH / 2) * angle)); }
	 */
	/**
	 * Sets the speed of both motors to the same values.
	 * 
	 * @param speed the speed in degrees per second
	 */
	public static void setSpeed(int speed) {
		setSpeeds(speed, speed);
	}

	/**
	 * Sets the speed of both motors to different values.
	 * 
	 * @param leftSpeed  the speed of the left motor in degrees per second
	 * @param rightSpeed the speed of the right motor in degrees per second
	 */
	public static void setSpeeds(int leftSpeed, int rightSpeed) {
		leftMotor.setSpeed(leftSpeed);
		rightMotor.setSpeed(rightSpeed);
	}

	/**
	 * Sets the acceleration of both motors.
	 * 
	 * @param acceleration the acceleration in degrees per second squared
	 */
	public static void setAcceleration(int acceleration) {
		leftMotor.setAcceleration(acceleration);
		rightMotor.setAcceleration(acceleration);
	}

	// go straight until there is a block. Then grab it. Do not call this method
	// unless there is a block ahead
	public static void straightSearchAndGrab() {
		leftMotor.setSpeed(FORWARD_SPEED);
		rightMotor.setSpeed(FORWARD_SPEED);
		leftMotor.forward();
		rightMotor.forward();
		while (true) {
			for (int i = 0; i < 25; i++) {
				readUsDistance();
			}
			int dist = readUsDistance();
			System.out.println(dist);
			if (dist < 3) {
				stopMotors();
				armMotor.setSpeed(FORWARD_SPEED);
				armMotor.rotate(-172, true); ///////////////////// TEST//////////////
				System.out.println("Arm deployed");
			}
		}

	}

	public static void Grab() {

		armMotor.setSpeed(FORWARD_SPEED);
		armMotor.rotate(-172, false); ///////////////////// TEST//////////////
		System.out.println("Arm deployed");

	}

	public static void Release() {

		armMotor.setSpeed(FORWARD_SPEED);
		armMotor.rotate(172, false); ///////////////////// TEST//////////////
		System.out.println("Arm deployed");

	}

}