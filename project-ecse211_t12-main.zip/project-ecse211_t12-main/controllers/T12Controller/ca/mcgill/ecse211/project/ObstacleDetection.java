package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Navigation.*;
import static ca.mcgill.ecse211.project.Resources.*;
import simlejos.hardware.sensor.EV3UltrasonicSensor;
import static simlejos.ExecutionController.sleepFor;
import ca.mcgill.ecse211.playingfield.Point;
import java.util.Arrays;

/**
* this class contains the necessary methods for the robot to navigate to a grid intersection 
* with the help of one or two color sensors.
*/
public class ObstacleDetection {
  final static double ERR_THRESHOLD = 0.05; // The distance at which object detection stops
  final static double DIST_THRESHOLD = 20; // The distance at which our robot avoids objects (cm)
  final static int DIST_SAMPLING = 100; // The rate at which the distance is sampled
  final static double CORR_DIST = 1; // The distance of our safepoint in ft
  final static int US_SWIVEL = 21; // The amount of US Sensor swivel from 0 degrees
  private static usSensorManager us;
  
  public static int initx = 1; // The initial x position of our robot (game coordinates)
  public static int inity = 8; // The initial y position of our robot (game coordinates)
  public static int[] startbounds = new int[] {0, 5, 4, 9}; // Bounds of starting island, {LLx, LLy, URx, URy}
  public static int[] gamebounds = new int[] {6, 5, 10, 9}; // Bounds of game island, {LLx, LLy, URx, URy}
  public static int placeholderbool = 1; // A placeholder for a flag that will indicate when the robot is on the game island
  public static int motorPos = 1000; // Indicates current usSensor angle, -1 corresponding to -20 degrees, 1 corresponding to 20 degrees
  public static int prevPos; // Stores the previous usSensor angle
  
  public static void readUs() {
    us = new usSensorManager(1);
    us.initSensor();
    int timePassed = 0;
    while(true) {
      System.out.println(us.readUsDistance());
      sleepFor(50);
      timePassed += 50;
    }
  }
  
  /**
   * avoidObstacles
   * Scans for obstacles while the robot is moving and avoids any it finds
   * Always samples with the top sensor
   * Calculations performed with values in metres unless otherwise indicated
   * @param dest The final destination of the robot, used to determine when to stop searching for objects
   */
  public static void avoidObstacles(Point dest) {
    Point corr = null; // The 'safe' point
    int[] bounds;
    double theta, distx, disty;
    
    /* Initialize motor position if needed */
    if(motorPos == 1000) {
      motorPos = 0;
      prevPos = 1;
      usMotor.setSpeed(250/*ROTATE_SPEED*/); // Set motor speed
    }
    
    /* Initializes startbounds and gamebounds the first time the method is called */
    if(startbounds == null && getWP("GreenTeam") == TEAM_NUMBER) {
      startbounds = new int[] {getWP("Green_LL_x"), getWP("Green_LL_y"), getWP("Green_UR_x"), getWP("Green_UR_y")};
      gamebounds = new int[] {getWP("SZG_LL_x"), getWP("SZG_LL_y"), getWP("SZG_UR_x"), getWP("SZG_UR_y")};
    }else if(startbounds == null && getWP("RedTeam") == TEAM_NUMBER) {
      startbounds = new int[] {getWP("Red_LL_x"), getWP("Red_LL_y"), getWP("Red_UR_x"), getWP("Red_UR_y")};
    }
    
    /* Determines which bounds array to use */
    if(placeholderbool == 1) {
      bounds = gamebounds;
    }else{
      bounds = startbounds;
    }
    
    /* Creates a new usSensorManager or resets the current one */
    if(us == null) {
      us = new usSensorManager(1);
    }else {
      us.initSensor();
    }
    
    /* Runs object detection code until the robot is sufficiently close to the destination */
    while(distToPoint(dest) > ERR_THRESHOLD && corr == null) {
      int flag = 1; // Determines direction of adjustments when moving close to a wall
      
      /* Swivels ultrasonic sensor before a reading is taken */
      if(motorPos < 0) {
        usMotor.rotate(US_SWIVEL, false);
        motorPos = 0;
        prevPos = -1;
      }else if(motorPos > 0) {
        usMotor.rotate(-US_SWIVEL, false);
        motorPos = 0;
        prevPos = 1;
      }else if (motorPos == 0) {
        usMotor.rotate(-prevPos*US_SWIVEL, false);
        motorPos = -prevPos;
        prevPos = 0;
      }
      
      theta = Odometer.getOdometer().getXyt()[2];
      
      /* determine appropriate distance components */
      if(inBounds(theta, 90, 18) || inBounds(theta, 270, 18)) {
        distx = us.readUsDistance();
        disty = DIST_THRESHOLD*DIST_THRESHOLD;
      }else if(inBounds(theta, 0, 18) || inBounds(theta, 180, 18)) {
        distx = DIST_THRESHOLD*DIST_THRESHOLD;
        disty = us.readUsDistance();
      }else {
        distx = us.readUsDistance()*Math.abs(Math.sin(theta*Math.PI/180));
        disty = us.readUsDistance()*Math.abs(Math.cos(theta*Math.PI/180));
      }
      
      //System.out.println(us.readUsDistance());
      //System.out.println("distx: " + distx + "disty: " + disty);
      if(distx < DIST_THRESHOLD || disty < DIST_THRESHOLD) { // Comparison in cm
        Navigation.stopMotors(); // Stop moving the robot
        
        System.out.println("OBJECT!! " + us.readUsDistance() + " " + distx + " " + disty + " " + theta);
        
        double x = Odometer.getOdometer().getXyt()[0]; // With respect to game origin
        double y = Odometer.getOdometer().getXyt()[1]; // With respect to game origin
        double vx = x - dest.x*TILE_SIZE; // Stores distance in x direction to the destination
        double vy = y - dest.y*TILE_SIZE; // Stores distance in y direction to the destination
        System.out.println(vx + " " + vy);
        
        if(inBounds(theta, 90, 45) || inBounds(theta, 270, 45)) {
          flag = -1;
        }else if(inBounds(theta, 0, 45) || inBounds(theta, 360, 45) || inBounds(theta, 180, 45)) {
          flag = 1;
        }
        
        /* 5 possible cases for robots position with respect to the boundaries */
        if(TILE_SIZE*bounds[3] - y < 1.5*CORR_DIST*TILE_SIZE && !inBounds(theta, 180, 35)) { // To close to the top boundary
          System.out.println("too close to top");
          flag = -1;
          corr = new Point(x/TILE_SIZE, y/TILE_SIZE - CORR_DIST); // The 'safe' point
        } else if(TILE_SIZE*bounds[2] - x < 1.5*CORR_DIST*TILE_SIZE && !inBounds(theta, 270, 35)) { // To close to the right boundary
          System.out.println("too close to right");
          flag = 1;
          corr = new Point(x/TILE_SIZE - CORR_DIST, y/TILE_SIZE); // The The 'safe' point
        } else if(y - TILE_SIZE*bounds[1] < 1.5*CORR_DIST*TILE_SIZE && (!inBounds(theta, 0, 35) && !inBounds(theta, 360, 35))) { // To close to the bottom boundary
          System.out.println("too close to bottom");
          flag = -1;
          corr = new Point(x/TILE_SIZE, y/TILE_SIZE + CORR_DIST); // The The 'safe' point
        } else if(x - TILE_SIZE*bounds[0] < 1.5*CORR_DIST*TILE_SIZE && !inBounds(theta, 90, 35)) { // To close to the left boundary
          System.out.println("too close to left");
          flag = 1;
          corr = new Point(x/TILE_SIZE + CORR_DIST, y/TILE_SIZE); // The 'safe' point
        } else { // Not nearby to any boundaries
          theta = Odometer.getOdometer().getXyt()[2];
          double dx, dy;
          
          /* Logic to compute required dx & dy to 'safe' point */
          if(theta < 90) {
            dx = -flag*CORR_DIST*Math.cos(theta*Math.PI/180);
            dy = flag*CORR_DIST*Math.sin(theta*Math.PI/180);
          }else if(theta < 180) {
            dx = -flag*CORR_DIST*Math.sin((theta-90)*Math.PI/180);
            dy = -flag*CORR_DIST*Math.cos((theta-90)*Math.PI/180);
          }else if(theta < 270) {
            dx = flag*CORR_DIST*Math.cos((theta-180)*Math.PI/180);
            dy = -flag*CORR_DIST*Math.sin((theta-180)*Math.PI/180);
          }else {
            dx = flag*CORR_DIST*Math.cos((theta-270)*Math.PI/180);
            dy = flag*CORR_DIST*Math.sin((theta-270)*Math.PI/180);
          }
          corr = new Point(x/TILE_SIZE + dx, y/TILE_SIZE + dy); // The 'safe' point
          System.out.println(corr.x + " " + corr.y);
        }
      }      
      sleepFor(DIST_SAMPLING);
    }
    
    if(corr != null) {
      System.out.println("correcting");
      Navigation.simpleTravel2(new Point(corr.x, odometer.getXyt()[1]/TILE_SIZE)); // Move to 'safe' point
      Navigation.simpleTravel2(corr);
      System.out.println("continuing on course");
      Navigation.simpleTravel2(new Point(dest.x, odometer.getXyt()[1]/TILE_SIZE)); // Move to 'safe' point
      Navigation.simpleTravel2(dest);
    }
  }
  /**
   * checkObstacle
   * Checks to see if there is an obstacle to the left or the right of the robot
   * @param direction The direction to check, should have a value of "Left" or "Right"
   * @return boolean True if there is an obstacle, False if there is no obstacle
   */
  public static boolean checkObstacle(String direction) {
    usMotor.setSpeed(ROTATE_SPEED); // Set motor speed
    boolean obstacle = false;
    
    /* Creates a new usSensorManager or resets the current one */
    if(us == null) {
      us = new usSensorManager(1);
    }
    
    if(motorPos != 1000) {
      usMotor.rotate(-motorPos*US_SWIVEL, false); // Reset us sensor swivel to 0 degrees
      motorPos = 1000; // Reset motorPos to indicate the usSensor must be reset next time
    }
    
    if(direction.equals("Left")) { // Check for obstacles to the left
      usMotor.rotate(-90, false);
      us.initSensor();
      
      obstacle = (us.readUsDistance() < DIST_THRESHOLD/2);
      usMotor.rotate(90, false); // Return sensor to neutral
    }else if(direction.equals("Right")) { // Check for obstacles to the right
      usMotor.rotate(90, false);
      us.initSensor();
      
      obstacle = (us.readUsDistance() < DIST_THRESHOLD/2);
      usMotor.rotate(-90, false); // Return sensor to neutral
    }
    
    return obstacle;
  }
  
  /**
   * errorToPoint
   * Calculates the euclidean distance to a given point in metres
   * @param p the point in question, coordinate system should use metres
   */
  public static double distToPoint(Point p) {
    double x = Odometer.getOdometer().getXyt()[0];
    double y = Odometer.getOdometer().getXyt()[1];
    return Math.sqrt((x-p.x*TILE_SIZE)*(x-p.x*TILE_SIZE) + (y-p.y*TILE_SIZE)*(y-p.y*TILE_SIZE));
  }
  
  /**
   * inBounds
   * Checks to see if a value is within 20 of the target value
   * @param val The real value
   * @param target The target value
   */
  public static boolean inBounds(double val, double target, double bound) {
    return (val <= target + bound) && (val >= target - bound); 
  }
  
  /**
   * getUs
   * Returns the usSensorManager object stored in this class
   */
  public static usSensorManager getUs() {
    if (us == null) {
      us = new usSensorManager(1);
    }else {
      us.initSensor();
    }
    
    return us;
  }
  
  /**
   * Manages the ultrasonic sensor used in obstacle detection and avoidance
   */
  public static class usSensorManager {
    /* The number of samples in the moving median window. */
    private static final int MOVING_MEDIAN_SAMPLE_COUNT = 10;
    
    /* The threshold distance for which US Sensor are considerd invalid. */
    private static final int THRESHOLD = 255;
    
    /* The sensor being managed */
    private static EV3UltrasonicSensor curSensor;
    
    private static int [] usMovingMedianData = new int[MOVING_MEDIAN_SAMPLE_COUNT]; // Stores the values used in calculating the median value
    private static int usSensorVal = 0; // Stores the current distance value

    /**
     * Creates a new usSensorManager object, managing sensor s
     * @param s The sensor being managed, 0 for lower, 1 for upper
     */
    usSensorManager(int s) {
      if(s == 0) {
        curSensor = Resources.usSensor;
      }else if(s == 1) {
        curSensor = Resources.usSensorTwo;
      }
      
      this.initSensor();
    }
    
    /**
     * Initializes the sensor array values.
     */
    public void initSensor() {
      for (int i = 0; i < MOVING_MEDIAN_SAMPLE_COUNT; i++) {
        usMovingMedianData[i] = (int) fetchSample();
        sleepFor(10);
      }
      
      usSensorVal = medianFilter(usMovingMedianData);
    }
    
    /**
     * Returns the filtered distance between the US sensor and an obstacle in cm.
     *   
     * @return the filtered distance between the US sensor and an obstacle in cm
     */
    public int readUsDistance() {
      /* Shift array values over to make space for new sample */
      for (int i = MOVING_MEDIAN_SAMPLE_COUNT - 1; i > 0; i--) {
        usMovingMedianData[i] = usMovingMedianData[i - 1];
      }
      
      // Get the current sample, ensure it is within the range of accepted values
      usMovingMedianData[0] = Math.min(THRESHOLD, (int) fetchSample()); 
      usSensorVal = medianFilter(usMovingMedianData);
      return usSensorVal;
    }
     
    /**
     * Fetchs an unfiltered sample from the sensor.
     */
    private static float fetchSample() {
      float[] distValue = new float[curSensor.sampleSize()];
      curSensor.fetchSample(distValue, 0);
      return distValue[0] * 100;
    }

    /**
     * Performs a median filter on a data set.
     * Uses bubble sort
     */
    public static int medianFilter(int[] data) {
      int median;
      int[] sortedData = new int[data.length];
      for (int i = 0; i < data.length; i++) {
        sortedData[i] = data[i]; // Copy values into new array
      } 
      Arrays.sort(sortedData);     
      if ((data.length) % 2 == 0) {
        median = (sortedData[data.length / 2] + sortedData[1 + data.length / 2]) / 2;
      } else {
        median = sortedData[data.length / 2];
      } 
      return median;
    }
  }
}
