/**
 * Wrapper class for webots to start the main project method.
 */
public class T12Controller {
  public static void main(String[] args) {
    ca.mcgill.ecse211.project.Main.main(args);
  }
}
